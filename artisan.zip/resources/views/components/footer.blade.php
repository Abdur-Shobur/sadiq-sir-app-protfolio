@php
    $profileData = $profile ?? \App\Models\Profile::first();

@endphp

<!-- ==================== Start Footer ==================== -->
<footer class="clean-footer crev" style="box-shadow: 0px 0px 1px 0px #000000">
	<div class="container pb-40 pt-40 ontop">
		<div class="row justify-content-between">
			<div class="col-lg-2">
				<div class="logo icon-img-100 md-mb80">
					@if($profileData && $profileData->logo_url)
						<img src="{{ $profileData->logo_url }}" alt="logo" />
					@else
						<img src="{{ asset('assets/imgs/logo-light.png') }}" alt="logo" />
					@endif
				</div>
			</div>
			<div class="col-lg-4">
				<div class="column md-mb50">
					<h6 class="sub-title mb-30">Contact</h6>
					<h6 class="p-color fw-400">
						{{ $profileData->address ?? 'Bangladesh University, Department of Computer Science & Engineering, Dhaka, Bangladesh' }}
					</h6>
					<h6 class="mt-30 mb-15">
						<a href="mailto:{{ $profileData->email ?? 'sadiq.iqbal@bu.edu.bd' }}">{{ $profileData->email ?? 'sadiq.iqbal@bu.edu.bd' }}</a>
					</h6>
					<a href="tel:{{ $profileData->phone ?? '+880 1755559312' }}" class="underline">
						<span class="fz-22 main-color">{{ $profileData->phone ?? '+880 1755559312' }}</span>
					</a>
				</div>
			</div>
			<div class="col-lg-2">
				<div class="column md-mb50">
					<h6 class="sub-title mb-30">Useful Links</h6>

					<ul class="rest fz-14 opacity-7">
						<li class="mb-15">
							<a href="/#about">About</a>
						</li>
						<li class="mb-15">
							<a href="/#research">Research</a>
						</li>
						<li class="mb-15">
							<a href="/blogs">Blog</a>
						</li>
						<li>
							<a href="/#contact">Contact</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="column subscribe-minimal">
					<h6 class="sub-title mb-30">Newsletter</h6>
					<div class="form-group mb-40">
						<input
							type="text"
							name="subscrib"
							placeholder="Your Email"
						/>
						<button><span class="fas fa-arrow-right"></span></button>
					</div>
					<ul class="rest social-icon d-flex align-items-center gap-1">
						@php
							$socialMedia = \App\Models\SocialMedia::getActive();
						@endphp

						@forelse($socialMedia as $social)
							<li class="hover-this cursor-pointer">
								<a class="hover-anim" href="{{ $social->url }}" target="_blank" title="{{ ucfirst($social->platform) }}">
								<img src="{{ asset('assets/imgs/icon/' . $social->getIconClass()) }}" alt="{{ ucfirst($social->platform) }}" style="width: 20px; height: 20px;">

								</a>
							</li>
						@empty
							<li class="hover-this cursor-pointer">
								<a href="#" class="text-muted">
									<i class="fas fa-share-alt"></i>
								</a>
							</li>
						@endforelse

						<!-- <li class="hover-this cursor-pointer">
							<a href="#0" class="hover-anim">
								<i class="fab fa-facebook-f"></i>
							</a>
						</li>
						<li class="hover-this cursor-pointer ml-10">
							<a href="#0" class="hover-anim">
								<i class="fab fa-dribbble"></i>
							</a>
						</li>
						<li class="hover-this cursor-pointer ml-10">
							<a href="#0" class="hover-anim">
								<i class="fab fa-linkedin-in"></i>
							</a>
						</li>
						<li class="hover-this cursor-pointer ml-10">
							<a href="#0" class="hover-anim">
								<i class="fab fa-instagram"></i>
							</a>
						</li> -->
					</ul>
				</div>
			</div>
		</div>
		<div class="pt-30 pb-30 mt-80 bord-thin-top">
			<div class="text-center">
				<p class="fz-14">
					© {{ date('Y') }} All Rights Reserved. Powered by <span  class="underline main-color"> Prof. Md Sadiq Iqbal
					</span>
				</p>
			</div>
		</div>
	</div>
	<div class="circle-blur">
		<img src="{{ asset('assets/imgs/patterns/blur1.png') }}" alt="" />
	</div>
</footer>
<!-- ==================== End Footer ==================== -->
