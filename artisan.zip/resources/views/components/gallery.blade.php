<section class="work-grid section-padding pb-0">
    <div class="container">
        <div class="row mb-40">
            <div class="col-lg-4">
                <div class="sec-head">
                    <h6 class="title-bord mb-30">Gallery</h6>
                    <h3>Through the Lens</h3>
                </div>
            </div>
            <!-- filter links -->
            <div class="filtering col-lg-8 d-flex justify-content-end align-items-end">
                <div>
                    <div class="filter">
                        <span data-filter="*" class="active" data-count="{{ $galleries->count() }}">All</span>
                        @php
                            $categories = $galleries->pluck('category.name')->unique()->filter();
                        @endphp
                        @foreach($categories as $categoryName)
                            <span data-filter=".{{ Str::slug($categoryName) }}" data-count="{{ $galleries->where('category.name', $categoryName)->count() }}">{{ $categoryName }}</span>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="gallery row md-marg">
            @forelse($galleries as $gallery)
            <div class="col-lg-4 col-md-6 items {{ $gallery->category ? Str::slug($gallery->category->name) : 'uncategorized' }}">
                <div class="item mb-50">
                    <div class="img">
                        @if($gallery->image_url)
                            <img class="research-img-300" style="object-fit: cover;" src="{{ $gallery->image_url }}" alt="{{ $gallery->title }}" />
                        @else
                            <img class="research-img-300" style="object-fit: cover;" src="{{ env('LAB_URL') }}/assets/img/placeholder.svg" alt="{{ $gallery->title }}" />
                        @endif
                    </div>
                    <div class="cont d-flex align-items-end mt-30">
                        <div>
                            <span class="p-color mb-5 sub-title">{{ $gallery->category->name ?? 'Uncategorized' }}</span>
                            <h6>{{ Str::limit($gallery->title, 30) }}</h6>
                            @if($gallery->description)
                                <p class="mt-2">{{ Str::limit($gallery->description, 60) }}</p>
                            @endif
                        </div>

                    </div>
                </div>
            </div>
            @empty
            <div class="col-12">
                <div class="text-center py-5">
                    <h5>No gallery items available</h5>
                    <p class="text-muted">Check back soon for new gallery content!</p>
                </div>
            </div>
            @endforelse
        </div>
    </div>
</section>
