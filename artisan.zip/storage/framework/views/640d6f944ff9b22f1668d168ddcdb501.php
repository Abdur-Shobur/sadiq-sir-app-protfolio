<!DOCTYPE html>
<html lang="zxx">
<head>
    <!-- Metas -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="keywords" content="HTML5 Template Webfolio Multi-Purpose themeforest" />
    <meta name="description" content="Webfolio - Multi-Purpose HTML5 Template" />
    <meta name="author" content="" />

    <!-- Title  -->
    <title><?php echo $__env->yieldContent('title', 'Webfolio'); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/imgs/favicon.ico')); ?>" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"  />    <!-- Plugins -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/plugins.css']); ?>

    <!-- Core Style Css -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
    <style>
        html{
            scroll-behavior: smooth;
        }
    </style>
</head>

<body>
    <!-- ==================== Start Loading ==================== -->
    <?php echo $__env->make('components.loader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Loading ==================== -->

    <div class="cursor"></div>

    <!-- ==================== Start progress-scroll-button ==================== -->
    <?php echo $__env->make('components.progress-scroll', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End progress-scroll-button ==================== -->

    <!-- ==================== Start Navbar ==================== -->
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Navbar ==================== -->

    <div class='position-relative' >
        <div >
            <main class="main-bg o-hidden">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <!-- ==================== Start Footer ==================== -->
            <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- ==================== End Footer ==================== -->
        </div>
    </div>
    <!-- ==================== End Main ==================== -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-migrate-3.4.0.min.js')); ?>"></script>

    <!-- plugins -->
    <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/gsap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/ScrollSmoother.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/ScrollTrigger.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/smoother-script.js')); ?>"></script>

    <!-- custom scripts -->
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\BU\portfolio\resources\views/layouts/app.blade.php ENDPATH**/ ?>