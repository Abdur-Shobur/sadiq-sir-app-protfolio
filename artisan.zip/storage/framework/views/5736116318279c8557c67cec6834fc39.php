<section class="feat section-padding" id="events">
    <div class="container ontop">
        <div class="row mb-60">
            <div class="col-12">
                <div class="cont md-mb50">
                    <h6 class="title-bord mb-30">Events</h6>
                    <h3 class="fw-600 fz-30 text-u d-rotate wow animated">Upcoming Events & Highlights</h3>
                    <p>Stay Informed About Our Latest Workshops, Seminars, and Conferences</p>
                </div>
            </div>
        </div>

        <div class="row g-4 justify-content-center">
        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class=" col-md-6 mb-4">
                    <div class="item h-100">
                    <div class="row h-100">
                        <div class="col-md-4 bg-img" data-background="<?php echo e($event->image_url ? $event->image_url : asset('assets/imgs/serv-img/default.jpg')); ?>"></div>
                        <div class="col-md-8">
                            <div class="info">
                                <h5 class="mb-15"><?php echo e(Str::limit($event->title, 40)); ?></h5>
                                <p><?php echo e(Str::limit($event->description, 80)); ?></p>
                                <div class="mt-3">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar-alt"></i> <?php echo e($event->event_date->format('M d, Y')); ?> |
                                        <i class="fas fa-clock"></i> <?php echo e($event->time); ?> |
                                        <i class="fas fa-map-marker-alt"></i> <?php echo e($event->location); ?>

                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 item">
                    <div class="row">
                        <div class="col-12">
                            <div class="info text-center">
                                <h5 class="mb-15">No upcoming events</h5>
                                <p>Check back soon for new events and activities!</p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
        </div>

    </div>
    <div class="circle-blur">
        <img src="<?php echo e(asset('assets/imgs/patterns/blur1.png')); ?>" alt="" />
    </div>
</section>
<?php /**PATH D:\BU\portfolio\resources\views/components/events.blade.php ENDPATH**/ ?>