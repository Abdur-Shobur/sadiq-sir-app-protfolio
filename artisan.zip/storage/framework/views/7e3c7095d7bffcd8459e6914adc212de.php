

<?php $__env->startSection('title', 'Prof. Md Sadiq Iqbal - Chairman, Department of Computer Science & Engineering'); ?>

<?php $__env->startSection('content'); ?>
    <!-- ==================== Start Header ==================== -->
    <?php echo $__env->make('components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Header ==================== -->

    <!-- ==================== Start intro ==================== -->
    <?php echo $__env->make('components.about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End intro ==================== -->

    <!-- ==================== Start Services ==================== -->
    <?php echo $__env->make('components.research', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Services ==================== -->

    <!-- ==================== Start feat ==================== -->
    <?php echo $__env->make('components.events', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End feat ==================== -->

    <!-- ==================== Start Services ==================== -->
    <?php echo $__env->make('components.achievements', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Services ==================== -->

    <!-- ==================== Start Portfolio ==================== -->
    <?php echo $__env->make('components.gallery', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Portfolio ==================== -->

    <!-- ==================== Start Blog ==================== -->
    <?php echo $__env->make('components.blog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Blog ==================== -->

    <!-- ==================== Start Contact ==================== -->
    <?php echo $__env->make('components.contact', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ==================== End Contact ==================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BU\portfolio\resources\views/home.blade.php ENDPATH**/ ?>