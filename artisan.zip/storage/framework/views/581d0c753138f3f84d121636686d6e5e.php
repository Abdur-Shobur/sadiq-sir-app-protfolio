<?php
    $achievements = \App\Models\Achievement::where('is_active', true)->latest()->take(6)->get();
?>

<?php if($achievements->count() > 0): ?>
<section class="services-inline2 section-padding sub-bg bord-bottom-grd bord-top-grd">
    <div class="container ontop">
        <div class="sec-head mb-40">
            <div class="d-flex align-items-center">
                <div>
                    <h6 class="title-bord mb-30">Achievements</h6>
                    <p>Celebrating Milestones and Success Stories</p>
                </div>
            </div>
        </div>

        <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item <?php echo e($loop->last ? 'pb-0' : ''); ?>">
            <div class="row md-marg align-items-end">
                <div class="col-lg-4">
                    <div>
                        <span class="num"><?php echo e(str_pad($index + 1, 2, '0', STR_PAD_LEFT)); ?></span>
                        <div>
                            <span class="sub-title main-color mb-10"><?php echo e($achievement->period); ?></span>
                            <h2><?php echo e($achievement->title); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text md-mb80">
                        <p><?php echo e($achievement->description); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="img fit-img">
                        <?php if($achievement->image_url): ?>
                            <img src="<?php echo e($achievement->image_url); ?>" alt="<?php echo e($achievement->title); ?>" />
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/imgs/serv-img/' . (($index % 3) + 1) . '.jpg')); ?>" alt="<?php echo e($achievement->title); ?>" />
                        <?php endif; ?>
                        <?php if($achievement->link): ?>
                            <a href="<?php echo e($achievement->link); ?>" target="_blank">
                            <i class="fas fa-arrow-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>
<?php /**PATH D:\BU\portfolio\resources\views/components/achievements.blade.php ENDPATH**/ ?>