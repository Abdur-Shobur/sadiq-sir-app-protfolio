

<?php $__env->startSection('title', $blog->title); ?>

<?php $__env->startSection('content'); ?>
<section class="blog-details section-padding mt-30">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="item">
                    <?php if($blog->image_url): ?>
                    <div class="img mb-30">
                        <img src="<?php echo e($blog->image_url); ?>" alt="<?php echo e($blog->title); ?>" class="w-100" />
                    </div>
                    <?php endif; ?>

                    <div class="info sub-title p-color d-flex align-items-center mb-30">
                        <div>
                            <a href="#"><?php echo e($blog->category->name ?? 'Uncategorized'); ?></a>
                        </div>
                        <div class="ml-30">
                            <a href="#"><?php echo e($blog->created_at->format('F d, Y')); ?></a>
                        </div>
                    </div>

                    <div class="cont">
                        <h2 class="mb-30"><?php echo e($blog->title); ?></h2>

                        <?php if($blog->excerpt): ?>
                        <div class="excerpt mb-30">
                            <p class="lead"><?php echo e($blog->excerpt); ?></p>
                        </div>
                        <?php endif; ?>

                        <div class="content">
                            <?php echo $blog->content; ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="sidebar">
                    <div class="widget mb-50">
                        <h6 class="title-bord mb-30">Recent Posts</h6>
                        <?php
                            $recentBlogs = \App\Models\Blog::with('category')
                                ->where('status', true)
                                ->where('id', '!=', $blog->id)
                                ->latest()
                                ->take(5)
                                ->get();
                        ?>

                        <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item mb-20">
                            <div class="img">
                                <?php if($recentBlog->image_url): ?>
                                    <img src="<?php echo e($recentBlog->image_url); ?>" alt="<?php echo e($recentBlog->title); ?>" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/imgs/blog/default.jpg')); ?>" alt="<?php echo e($recentBlog->title); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="cont">
                                <h6><a href="<?php echo e(route('blogs.show', $recentBlog->id)); ?>"><?php echo e(Str::limit($recentBlog->title, 40)); ?></a></h6>
                                <span class="date"><?php echo e($recentBlog->created_at->format('M d, Y')); ?></span>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BU\portfolio\resources\views/blogs/show.blade.php ENDPATH**/ ?>