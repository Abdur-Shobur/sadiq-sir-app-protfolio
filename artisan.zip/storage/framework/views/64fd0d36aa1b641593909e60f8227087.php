<section class="blog style2 pt-40" id="blog">
    <div class="container">
        <div class="sec-head mb-40">
            <div class="d-flex align-items-center">
                <div>
                    <h3 class="title-bord mb-30">Blogs</h3>
                </div>
                <div class="ml-auto vi-more">
                    <a href="<?php echo e(route('blogs.index')); ?>" class="butn butn-sm butn-bord radius-30">
                        <span>View All</span>
                    </a>
                    <i class="icon fas fa-arrow-right"></i>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4">
                <div class="item md-mb50">
                    <div class="info sub-title p-color d-flex align-items-center mb-20 " style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
                        <div>
                            <a href="#"><?php echo e($blog->category->name ?? 'Uncategorized'); ?></a>
                        </div>
                        <div class="ml-30">
                            <a href="#"><?php echo e($blog->created_at->format('F d, Y')); ?></a>
                        </div>
                    </div>
                    <div class="img fit-img" style="background: #191919;">
                        <?php if($blog->image_url): ?>
                            <img src="<?php echo e($blog->image_url); ?>" alt="<?php echo e($blog->title); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="cont pt-30">
                        <a href="<?php echo e(route('blogs.show', $blog->id)); ?>">
                        <h5><?php echo e(Str::limit($blog->title, 50)); ?></h5>
                        </a>
                        <a href="<?php echo e(route('blogs.show', $blog->id)); ?>" class="butn-crev d-flex align-items-center mt-30">
                            <span class="hover-this">
                                <span class="circle hover-anim">
                                <i class="fas fa-arrow-right"></i>
                                </span>
                            </span>
                            <span class="text">Read more</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <h5>No blog posts available</h5>
                    <p class="text-muted">Check back soon for new content!</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH D:\BU\portfolio\resources\views/components/blog.blade.php ENDPATH**/ ?>