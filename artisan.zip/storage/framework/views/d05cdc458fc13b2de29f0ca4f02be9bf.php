<?php if($about && $about->is_active): ?>
<section class="page-intro section-padding pb-0" id="about">
    <div class="container">
        <div class="row md-marg">
            <div class="col-lg-6">
                <div class="img md-mb80">
                    <div class="row">
                        <div class="col-6">
                            <?php if($about->image1_url): ?>
                                <img src="<?php echo e($about->image1_url); ?>" alt="<?php echo e($about->title); ?>" />
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/imgs/intro/i1.jpg')); ?>" alt="<?php echo e($about->title); ?>" />
                            <?php endif; ?>
                            <div class="img-icon">
                                <img src="<?php echo e(asset('assets/imgs/arw0.png')); ?>" alt="" />
                            </div>
                        </div>
                        <div class="col-6 mt-40">
                            <?php if($about->image2_url): ?>
                                <img src="<?php echo e($about->image2_url); ?>" alt="<?php echo e($about->title); ?>" />
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/imgs/intro/i2.jpg')); ?>" alt="<?php echo e($about->title); ?>" />
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 valign">
                <div class="cont">
                    <h6 class="title-bord mb-30"><?php echo e($about->title); ?></h6>
                    <h3 class="mb-30">
                        <?php echo e($about->subtitle); ?>

                    </h3>
                    <p>
                        <?php echo e($about->description); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH D:\BU\portfolio\resources\views/components/about.blade.php ENDPATH**/ ?>