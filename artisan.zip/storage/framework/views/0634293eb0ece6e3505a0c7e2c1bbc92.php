<section class="work-grid section-padding pb-0">
    <div class="container">
        <div class="row mb-40">
            <div class="col-lg-4">
                <div class="sec-head">
                    <h6 class="title-bord mb-30">Gallery</h6>
                    <h3>Through the Lens</h3>
                </div>
            </div>
            <!-- filter links -->
            <div class="filtering col-lg-8 d-flex justify-content-end align-items-end">
                <div>
                    <div class="filter">
                        <span data-filter="*" class="active" data-count="<?php echo e($galleries->count()); ?>">All</span>
                        <?php
                            $categories = $galleries->pluck('category.name')->unique()->filter();
                        ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span data-filter=".<?php echo e(Str::slug($categoryName)); ?>" data-count="<?php echo e($galleries->where('category.name', $categoryName)->count()); ?>"><?php echo e($categoryName); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="gallery row md-marg">
            <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 items <?php echo e($gallery->category ? Str::slug($gallery->category->name) : 'uncategorized'); ?>">
                <div class="item mb-50">
                    <div class="img">
                        <?php if($gallery->image_url): ?>
                            <img class="research-img-300" style="object-fit: cover;" src="<?php echo e($gallery->image_url); ?>" alt="<?php echo e($gallery->title); ?>" />
                        <?php else: ?>
                            <img class="research-img-300" style="object-fit: cover;" src="<?php echo e(env('LAB_URL')); ?>/assets/img/placeholder.svg" alt="<?php echo e($gallery->title); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="cont d-flex align-items-end mt-30">
                        <div>
                            <span class="p-color mb-5 sub-title"><?php echo e($gallery->category->name ?? 'Uncategorized'); ?></span>
                            <h6><?php echo e(Str::limit($gallery->title, 30)); ?></h6>
                            <?php if($gallery->description): ?>
                                <p class="mt-2"><?php echo e(Str::limit($gallery->description, 60)); ?></p>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <h5>No gallery items available</h5>
                    <p class="text-muted">Check back soon for new gallery content!</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH D:\BU\portfolio\resources\views/components/gallery.blade.php ENDPATH**/ ?>