<?php
    $profileData = $profile ?? \App\Models\Profile::first();

?>

<!-- ==================== Start Footer ==================== -->
<footer class="clean-footer crev" style="box-shadow: 0px 0px 1px 0px #000000">
	<div class="container pb-40 pt-40 ontop">
		<div class="row justify-content-between">
			<div class="col-lg-2">
				<div class="logo icon-img-100 md-mb80">
					<?php if($profileData && $profileData->logo_url): ?>
						<img src="<?php echo e($profileData->logo_url); ?>" alt="logo" />
					<?php else: ?>
						<img src="<?php echo e(asset('assets/imgs/logo-light.png')); ?>" alt="logo" />
					<?php endif; ?>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="column md-mb50">
					<h6 class="sub-title mb-30">Contact</h6>
					<h6 class="p-color fw-400">
						<?php echo e($profileData->address ?? 'Bangladesh University, Department of Computer Science & Engineering, Dhaka, Bangladesh'); ?>

					</h6>
					<h6 class="mt-30 mb-15">
						<a href="mailto:<?php echo e($profileData->email ?? 'sadiq.iqbal@bu.edu.bd'); ?>"><?php echo e($profileData->email ?? 'sadiq.iqbal@bu.edu.bd'); ?></a>
					</h6>
					<a href="tel:<?php echo e($profileData->phone ?? '+880 1755559312'); ?>" class="underline">
						<span class="fz-22 main-color"><?php echo e($profileData->phone ?? '+880 1755559312'); ?></span>
					</a>
				</div>
			</div>
			<div class="col-lg-2">
				<div class="column md-mb50">
					<h6 class="sub-title mb-30">Useful Links</h6>

					<ul class="rest fz-14 opacity-7">
						<li class="mb-15">
							<a href="/#about">About</a>
						</li>
						<li class="mb-15">
							<a href="/#research">Research</a>
						</li>
						<li class="mb-15">
							<a href="/blogs">Blog</a>
						</li>
						<li>
							<a href="/#contact">Contact</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="column subscribe-minimal">
					<h6 class="sub-title mb-30">Newsletter</h6>
					<div class="form-group mb-40">
						<input
							type="text"
							name="subscrib"
							placeholder="Your Email"
						/>
						<button><span class="fas fa-arrow-right"></span></button>
					</div>
					<ul class="rest social-icon d-flex align-items-center gap-1">
						<?php
							$socialMedia = \App\Models\SocialMedia::getActive();
						?>

						<?php $__empty_1 = true; $__currentLoopData = $socialMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<li class="hover-this cursor-pointer">
								<a class="hover-anim" href="<?php echo e($social->url); ?>" target="_blank" title="<?php echo e(ucfirst($social->platform)); ?>">
								<img src="<?php echo e(asset('assets/imgs/icon/' . $social->getIconClass())); ?>" alt="<?php echo e(ucfirst($social->platform)); ?>" style="width: 20px; height: 20px;">

								</a>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<li class="hover-this cursor-pointer">
								<a href="#" class="text-muted">
									<i class="fas fa-share-alt"></i>
								</a>
							</li>
						<?php endif; ?>

						<!-- <li class="hover-this cursor-pointer">
							<a href="#0" class="hover-anim">
								<i class="fab fa-facebook-f"></i>
							</a>
						</li>
						<li class="hover-this cursor-pointer ml-10">
							<a href="#0" class="hover-anim">
								<i class="fab fa-dribbble"></i>
							</a>
						</li>
						<li class="hover-this cursor-pointer ml-10">
							<a href="#0" class="hover-anim">
								<i class="fab fa-linkedin-in"></i>
							</a>
						</li>
						<li class="hover-this cursor-pointer ml-10">
							<a href="#0" class="hover-anim">
								<i class="fab fa-instagram"></i>
							</a>
						</li> -->
					</ul>
				</div>
			</div>
		</div>
		<div class="pt-30 pb-30 mt-80 bord-thin-top">
			<div class="text-center">
				<p class="fz-14">
					© <?php echo e(date('Y')); ?> All Rights Reserved. Powered by <span  class="underline main-color"> Prof. Md Sadiq Iqbal
					</span>
				</p>
			</div>
		</div>
	</div>
	<div class="circle-blur">
		<img src="<?php echo e(asset('assets/imgs/patterns/blur1.png')); ?>" alt="" />
	</div>
</footer>
<!-- ==================== End Footer ==================== -->
<?php /**PATH D:\BU\portfolio\resources\views/components/footer.blade.php ENDPATH**/ ?>